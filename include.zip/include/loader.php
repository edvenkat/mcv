<?php
include_once("config.php");

/** Load Class Filess */
require_once("session.inc");
require_once("mysql.inc");
require_once("db.inc");
require_once("userfunctions.inc");
require_once("paging.inc");
require_once("functions.php");

/** Create database object */
$sqlobj=new dbconn(_HOSTNAME, _USERNAME, _PASSWORD, _DATABASE);

/** Create session object */
$sesobj=new SESSION_MANAGEMENT();

/** Create UserFunctions object */
$userobj=new UserFunctions();

/** Create Pageing Object */
$pageobj=new Pageing('5');

define("HTTPS_URL", "http://192.168.2.14//ilovemywaitress/");
define("HTTP_URL", "http://192.168.2.14/ilovemywaitress/");

$bcc_array = array("vinsinfo@terencenet.com");


function person($personid) {
	switch($personid) {
		case 1:
			return frequenter;
			break;
		case 2:
			return waiter;
			break;
		case 3:
			return frequenter;
			break;
	}
}
?>
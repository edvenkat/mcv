<?php
// DATABSE INFORMATION
	/* define("_HOSTNAME", "192.168.0.19");
	define("_USERNAME", "anto");
	define("_PASSWORD", "123456");
	define("_DATABASE", "johncarrollhigh"); */

define("_HOSTNAME", "192.168.2.14");
define("_USERNAME", "anto");
define("_PASSWORD", "123456");
define("_DATABASE", "ilike");

 //To Test the Email
$emailtest =  "ranjith@vinsinfo.com";
?>
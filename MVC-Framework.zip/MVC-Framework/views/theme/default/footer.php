<?php 
echo "footer";
?>
<?php 

class AppController {
	protected $environment = NULL;
	protected $theme	   = NULL;

	public function __construct() {
		if(! isset($_SESSION)) {
			session_start();
		}
	}

	public function renderView($view_file, $params = array()) {
		extract($params);

		if($this->theme && is_file( VIEW_ROOT.'theme/'.$this->theme.'/header.php' )) {
			require_once VIEW_ROOT.'theme/'.$this->theme.'/header.php';
		}
		if( is_file( VIEW_ROOT.$view_file.'.php' ) ) {
			require_once VIEW_ROOT.$view_file.'.php';
		} else if( is_dir( VIEW_ROOT.$view_file ) ) {
			require_once VIEW_ROOT.$view_file.'/index.php';
		} else {
			throw new Exception("ERROR - View File '{$view_file}.php' Does Not EXIST.");
		}
		if($this->theme && is_file( VIEW_ROOT.'theme/'.$this->theme.'/footer.php' )) {
			require_once VIEW_ROOT.'theme/'.$this->theme.'/footer.php';
		}
	}
}

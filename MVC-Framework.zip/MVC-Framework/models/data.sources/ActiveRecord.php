<?php

	require_once ( VENDOR_ROOT."activerecord/ActiveRecord.php" );

	class ActiveRecord {

		public static function startActiveRecord() {
            date_default_timezone_set('America/New_York');

			ActiveRecord\Config::initialize(function($cfg) {
				InIConfig::initializeConfig( Environment::iniConfig() );
				$db_config = InIConfig::getSectionParams("MySql");
				
				if(!isset($db_config) || Util::isEmpty($db_config["data.source"]) ||
					Util::isEmpty($db_config["database"]) || Util::isEmpty($db_config["host"]) ||
					Util::isEmpty($db_config["user.name"]) || Util::isEmpty($db_config["password"])) {
					throw new Exception(__METHOD__.": ERROR - Database connection parameters not set.");
				}
				$connection_string = $db_config["data.source"]."://".$db_config["user.name"].":"
					.$db_config["password"]."@".$db_config["host"]."/".$db_config["database"];
				//var_dump($connection_string);

				$cfg->set_model_directory('models');
				$cfg->set_connections(
					array(
						'config' => $connection_string
					)
				);
				$cfg->set_default_connection('config');
			});
		}
	}
	
	ActiveRecord::startActiveRecord();
	

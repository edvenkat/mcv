<?php

require_once ( __DIR__.'/config/Constant.php' );

$router = new AltoRouter;

if(_ALTO_BASE_PATH_ != '') {
	$router->setBasePath( _ALTO_BASE_PATH_ );
}

//Routing Conditions
/* Main controller */
$router->map('POST|GET' ,'/', array('controller' => 'MainController', 'method' => 'index'));


if($match) {
	Routes::Initialize($match);
} else {
    header($_SERVER["SERVER_PROTOCOL"] . ' 404 Not Found');
	echo '404 Error';
}
//Match Routing
$match = $router->match();


if($match) {
	Routes::Initialize($match);
} else {
    header($_SERVER["SERVER_PROTOCOL"] . ' 404 Not Found');
	echo '404 Error';
}

<?php
/**
 * Created by PhpStorm.
 * User: reed.clarke
 * Date: 6/4/2015
 * Time: 11:16 AM
 */

 class Routes {
	public static function Initialize($match) {
		try {
			if($match['target']) {
				extract($match['target']);

				if( is_file(CONTROLLER_ROOT.$controller.'.php') ) {
					require_once CONTROLLER_ROOT.$controller.'.php';
				} else {
					throw new Exception("ERROR - Controller '{$target_array[0]}.php' Does Not Exist ");
				}				
				
				$contoller_obj  = new $controller;
				$callable_array = array($contoller_obj, $method);
				
				$param['match_array'] = array_merge($match['target'], $match['params']);

				if(is_callable($callable_array)) {
					call_user_func_array($callable_array, $param);
				} else {
					throw new Exception("ERROR - Can't Access ".$match['target']['controller']."::{$target_array[1]}().");
				}
			}
		} catch(Exception $e) {
			echo $e->getMessage();
		}
	}
 }
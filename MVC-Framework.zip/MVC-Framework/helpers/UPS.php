<?php
/*
PackagingType
#############
	'00' (unknown),
	'01' (UPS letter),
	'02' (customer supplied package),
	'03'  (tube),
	'04' (PAK),
	'21' (UPS express box),
	'2a' (UPS small express box),
	'2b' (UPS  medium express box),
	'2c' (UPS large express box),
	'24' (UPS 25KG box),
	'25' (UPS  10KG box),
	'2a' (small express box),
	'2b' (medium express box),
	'2c' (large express  box),
	'30' (pallet)


PickupType
##########
	'01' (daily pickup),
	'03' (customer counter),
	'06' (one time pickup),
	'07' (on call air),
	 '11' (suggested retail rates),
	'19' (letter center),
	'20' (air service center)

Dimensions
##########
Length -
Width -
Height -
Weight -
	
Service Type:
#############
01 UPS Next Day Air�
02 UPS Second Day Air�
03 UPS Ground
07 UPS Worldwide ExpressSM
08 UPS Worldwide ExpeditedSM
11 UPS Standard
12 UPS Three-Day Select�
14 UPS Next Day Air� Early A.M. SM
54 UPS Worldwide Express PlusSM
59 UPS Second Day Air A.M.�
65 UPS Saver
*/
class UPS {
	function UPS() {
		$this->error="";
		$this->alnumber='EC66A11C0F3FBE18'; // Your license number
		$this->userid='richardsons1'; // Username
		$this->password='hunter'; // Password
		$this->shippernumber='71X51X'; // Your UPS shipper number
		$this->postalcode='02745'; // Zipcode you are shipping FROM
	}
	function getRate($dest_zip,$service,$weight,$length,$width,$height) {
		$data ="<?xml version=\"1.0\"?>
		<AccessRequest xml:lang=\"en-US\">
			<AccessLicenseNumber>$this->alnumber</AccessLicenseNumber>
			<UserId>$this->userid</UserId>
			<Password>$this->password</Password>
		</AccessRequest>
		<?xml version=\"1.0\"?>
		<RatingServiceSelectionRequest xml:lang=\"en-US\">
			<Request>
				<TransactionReference>
					<CustomerContext>Richardsons Map</CustomerContext>
					<XpciVersion>1.0001</XpciVersion>
				</TransactionReference>
				<RequestAction>Rate</RequestAction>
				<RequestOption>Rate</RequestOption>
			</Request>
		<PickupType>
			<Code>06</Code>
			<Description>One Time Pickup</Description>
		</PickupType>
		<Shipment>
			<Shipper>
				<Address>
					<PostalCode>$this->postalcode</PostalCode>
					<CountryCode>US</CountryCode>
				</Address>
			<ShipperNumber>$this->shippernumber</ShipperNumber>
			</Shipper>
			<ShipTo>
				<Address>
					<PostalCode>$dest_zip</PostalCode>
					<CountryCode>US</CountryCode>
				<ResidentialAddressIndicator/>
				</Address>
			</ShipTo>
			<ShipFrom>
				<Address>
					<PostalCode>$this->postalcode</PostalCode>
					<CountryCode>US</CountryCode>
				</Address>
			</ShipFrom>
			<Service>
				<Code>$service</Code>
			</Service>
			<Package>
				<PackagingType>
					<Code>00</Code>
					<Description>Unknown</Description>
				</PackagingType>
				<Dimensions>
					<UnitOfMeasurement>
						<Code>IN</Code>
					</UnitOfMeasurement>
					<Length>$length</Length>
					<Width>$width</Width>
					<Height>$height</Height>
				</Dimensions>
				<PackageWeight>
					<UnitOfMeasurement>
						<Code>LBS</Code>
					</UnitOfMeasurement>
					<Weight>$weight</Weight>
				</PackageWeight>
			</Package>
		</Shipment>
		</RatingServiceSelectionRequest>";
		$ch = curl_init("https://www.ups.com/ups.app/xml/Rate");
		curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch,CURLOPT_POST,1);
		curl_setopt($ch,CURLOPT_TIMEOUT, 60);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
		$result=curl_exec ($ch);
	//echo '<!-- '. $result. ' -->'; // THIS LINE IS FOR DEBUG PURPOSES ONLY-IT WILL SHOW IN HTML COMMENTS
		$data = strstr($result, '<?');
		$xml_parser = xml_parser_create();
		xml_parse_into_struct($xml_parser, $data, $vals, $index);
		xml_parser_free($xml_parser);
		$params = array();
		$level = array();
		foreach ($vals as $xml_elem) {
		 if ($xml_elem['type'] == 'open') {
		if (array_key_exists('attributes',$xml_elem)) {
			 list($level[$xml_elem['level']],$extra) = array_values($xml_elem['attributes']);
		} else {
			 $level[$xml_elem['level']] = $xml_elem['tag'];
		}
		 }
		 if ($xml_elem['type'] == 'complete') {
		$start_level = 1;
		$php_stmt = '$params';
		while($start_level < $xml_elem['level']) {
			 $php_stmt .= '[$level['.$start_level.']]';
			 $start_level++;
		}
		$php_stmt .= '[$xml_elem[\'tag\']] = $xml_elem[\'value\'];';
		eval($php_stmt);
		 }
		}
		curl_close($ch);
		if($params['RATINGSERVICESELECTIONRESPONSE']["RESPONSE"]["RESPONSESTATUSCODE"]=="0" || count($params)==0) {
			$this->error=$params['RATINGSERVICESELECTIONRESPONSE']["RESPONSE"]["ERROR"]["ERRORDESCRIPTION"];
			if(count($params)==0) {
				$this->error="Not Loaded Properly";
			}			
		}
		return $params['RATINGSERVICESELECTIONRESPONSE']['RATEDSHIPMENT']['TOTALCHARGES']['MONETARYVALUE'];
	}
}

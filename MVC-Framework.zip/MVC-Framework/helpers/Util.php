<?php

	/*
	* Util
	*
	* @author reed.clarke May 1, 2012
	*/

	/*
    if(!defined('__HELPERS_ROOT__'))define('__HELPERS_ROOT__', dirname(dirname(__FILE__)));
	*/

	class Util {

        public static function isEmpty($var) {
			$empty = false;
			if(is_null($var)) {
				$empty = true;
			} else if(is_array($var) && count($var) == 0) {
				$empty = true;
			} else if((gettype($var) == "string") && strlen(trim($var)) == 0) {
				$empty = true;
			}
			return $empty;
		}
				
		public static function isNotEmpty($var) {
			return !self::isEmpty($var);
		}
		
		public static function numberOfDays($start_date, $end_date) {
			return (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24);
		}
		
		public static function timeDiff($date_time1, $date_time2) {
			date_default_timezone_set('UTC');
			$date_time1_parts = explode(" ", $date_time1);
			$date1 = $date_time1_parts[0];
			$date1_parts = explode("-", $date1);
			$time1 = $date_time1_parts[1];
			$time1_parts = explode(":", $time1);
			$date_time2_parts = explode(" ", $date_time2);
			$date2 = $date_time2_parts[0];
			$date2_parts = explode("-", $date2);
			$time2 = $date_time2_parts[1];
			$time2_parts = explode(":", $time2);
			return floor((mktime($time2_parts[0],$time2_parts[1],'00',$date2_parts[1],$date2_parts[2],$date2_parts[0]) - mktime($time1_parts[0],$time1_parts[1],'00',$date1_parts[1],$date1_parts[2],$date1_parts[0]))/60);
		}
		
		public static function removeNonPrintableCharacters($data) { 
			return  preg_replace( '/[^[:print:]]/', '',$data);
		}
		
		public static function removeLastChar($string) {
			return substr_replace($string, "", -1);
		}
	
		public static function cleanXml($xmlString) {
			$search = array("<![CDATA[", "]]>", "<\/table>", "<\/tr>", "<\/td>", "<\/div>", "<\/li>", "&");
			$replace = array("", "", "", "", "", "", "", "and");
			return str_replace($search , $replace , $xmlString);
		}
		
		public static function cleanXmlData($data) {
			$data = self::removeNonPrintableCharacters(html_entity_decode($data));
			if(self::contains($data, "<ul") || self::contains($data, "<table") || self::contains($data, "<tr") || self::contains($data, "<td") || 
				self::contains($data, "<div") || self::contains($data, "<li") || self::contains($data, "<img")) {
				$data = "";
			}
			return $data;
		}

		public static function refValues($array){
			$values = null;
			//Reference is required for PHP 5.3+
			if (strnatcmp(phpversion(),'5.3') >= 0)	{
				$refs = array();
				foreach($array as $key => $value) {
					$refs[$key] = &$array[$key];
				}
				$values = $refs;
			} else {
				$values = $array;
			}
			return $values;
		}		

		public static function paramString(array $params = null) {
			$param_string = null;
			if(!is_null($params) && self::isNotEmpty($params)) {
				foreach($params as $key => $value) {
					if(self::isNotEmpty($value)) {
						$param_string .= "&";
						$param_string .= $key;
						$param_string .= "=";
						$param_string .= $value;
					}
				}
			}
			return $param_string;
		}
		
		public static function flattenArray(array $array) {
			$result = array();
			if (is_array($array)) {
				foreach ($array as $k => $v) {
					if (is_array($v)) {
						$result = array_merge($result, self::flattenArray($v));
					} else {
						$result[] = $v;
					}
				}
			}
			return $result;
		}

		public static function sortObjectArrayByColumn($unsorted_array_of_objects, $column, $sord = "asc") {
			$dir = 0;
			if($sord == "desc") {
				$dir = SORT_DESC;
			} else {
				$dir = SORT_ASC;
			}
			$sort_col = array();
			foreach ($unsorted_array_of_objects as $key => $row) {
				$sort_col[$key] = $row->{$column};
			}
			$array_of_arrays = array();
			// change array of objects to array of array
			foreach($unsorted_array_of_objects as $row) {
				array_push($array_of_arrays, get_object_vars($row));
			}
			//SORT_NUMERIC, SORT_STRING, SORT_DESC
			array_multisort($sort_col, $dir, $array_of_arrays);
			// change array of arrays back to array of objects
			$sorted_array_of_objects = array();
			foreach($array_of_arrays as $row) {
				$array_of_objects = self::array_to_object($row);
				array_push($sorted_array_of_objects, $array_of_objects);
			}
			return $sorted_array_of_objects;
		}
		
		public static function searchObjectArrayByColumn($array_of_objects, $search_field, $search_oper, $search_string) {
			$search_data = array();
			foreach($array_of_objects as $row) {
				switch ($search_oper) {
					case 'eq':
						if(self::equals($row->{$search_field}, $search_string)) {
							array_push($search_data, $row);
						}
						break;
					case 'ne':
						if(!self::equals($row->{$search_field}, $search_string)) {
							array_push($search_data, $row);
						}
						break;
					case 'bw':
						if(self::startsWith($row->{$search_field}, $search_string)) {
							array_push($search_data, $row);
						}
						break;
					case 'ew':
						if(self::endsWith($row->{$search_field}, $search_string)) {
							array_push($search_data, $row);
						}
						break;
					case 'cn':
						if(self::contains($row->{$search_field}, $search_string)) {
							array_push($search_data, $row);
						}
						break;
					case 'nc':
						if(!self::contains($row->{$search_field}, $search_string)) {
							array_push($search_data, $row);
						}
						break;
					default:
						break;
				}
			}
			return $search_data;
		}
		
		public static function asoccArrayValueWithNumKey($array, $key) {
			if (!(count($array) > $key)) {
				return false;
			}
			reset($array);
			$aux = -1;
			$found = false;
			while (!$found) {
				$aux++;
				$auxKey = key($array);
				next($array);
				$found = ($aux == $key);
			}
			if ($found) {
				return $array[$auxKey];
			} else {
				return false;
			}
		}
		
		static public function array_to_object(array $array) {
			# Iterate through our array looking for array values.
			# If found recurvisely call itself.
			foreach($array as $key => $value) {
				if(is_array($value)) {
					$array[$key] = self::array_to_object($value);
				}
			}
			# Typecast to (object) will automatically convert array -> stdClass
			return (object)$array;
		}

		static public function object_to_array($object) {
			return json_decode(json_encode($object), true);
		}

		static public function equals($haystack, $needle) {
			$equal = false;	
			if(strcmp($haystack, $needle) == 0) {
				$equal = true;
			}
			return $equal;
		}
		
		static public function startsWith($haystack, $needle) {
			return substr($haystack, 0, strlen($needle)) == $needle;
		}
		
		static public function endsWith($haystack, $needle)	{
			return substr($haystack, -strlen($needle)) == $needle;
		}
		
		static public function contains($haystack, $needle) {
			$found = false;
			if(strpos($haystack, $needle) !== false) {
				$found = true;
			}
			return $found;
		}
		
		static public function truncate($string, $length) {
			if(strlen($string) > $length) {
				$string = substr($string, 0, $length);
			}
			return $string;
		}
		
		static function getMemoryUnits($size) {
			$units = array('b','kb','mb','gb','tb','pb');
			return @round($size/pow(1024, ($i = floor(log($size, 1024)))), 2).' '.$units[$i];
		}

        static function is_ajax() {
            return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
        }

		public static function getVariable($key, $default_value = "")
		{
			if(isset($_POST[$key]))
				return $_POST[$key];
			else if(isset($_GET[$key]))
				return $_GET[$key];
			else
				return $default_value;
		}

		public static function fileCheck($filename) {
			return self::is_file($filename);
		}

		public static function tmpFileCheck($filename) {
			return self::filecheck(_PATH_TEMPLATE.$filename.".php");
		}

		public static function codeFileCheck($filename) {
			return self::filecheck(_PATH_CODE.$filename.".php");
		}

		public static function splitWord($word, $offset) {
			$temp = "";
			if($temp1 = explode(" ",$word))
			{
				for($i = 0; $i < $offset; $i++)
				{
					$temp .= " ".$temp1[$i];
				}
				if(isset ($temp1[$offset + 1]))
				{
					$temp .= "... ";
				}
			}
			return $temp;
		}

		public static function splitChar($word, $offset) {
			if(strlen($word) > $offset)
			{
				$temp = substr($word, 0, $offset)."...";
			}
			else {
				$temp = $word;
			}
			return $temp;
		}

		public static function formCheck($fields, $alret_message) {
			$msg = "";
			for($i = 0; $i < count($fields); $i++) {
				if(self::getVariableFromRequest($fields[$i]) === ""){
					$msg = "Please fill the ".$alret_message[$i].".";
					break;
				}
			}
			return $msg;
		}

		public static function covertDateToTimestamp($date) {
			if($date !== "") {
				$date_array = split('/',$date);
				return mktime (0, 0, 0, $date_array[0], $date_array[1], $date_array[2]);
			}
			return "";
		}

		public static function XOREncryption($InputString, $KeyPhrase) {
			$KeyPhraseLength = strlen($KeyPhrase);
			for ($i = 0; $i < strlen($InputString); $i++) {
				$rPos = $i % $KeyPhraseLength;
				$r = ord($InputString[$i]) ^ ord($KeyPhrase[$rPos]);
				$InputString[$i] = chr($r);
			}
			return $InputString;
		}

		public static function XOREncrypt($InputString, $KeyPhrase="terence") {
			$InputString="<!<enc>!>".$InputString;
			$InputString = self::XOREncryption($InputString, $KeyPhrase);
			$InputString = base64_encode($InputString);
			return $InputString;
		}

		public static function XORDecrypt($InputString, $KeyPhrase="terence") {
			$InputString_old=$InputString;
			$InputString = base64_decode($InputString);
			$InputString = self::XOREncryption($InputString, $KeyPhrase);
			if(!stristr($InputString,"<!<enc>!>")) {
				$InputString=$InputString_old;	
			} else {
				$InputString=str_replace('<!<enc>!>','',$InputString);
			}
			return $InputString;
		}
		public static function getArray($arr_obj){
			$arr_res = array();
			if(count($arr_obj)>0){
				foreach($arr_obj as $k => $v){
					$arr_res[]=$v->to_array();
				}
				return $arr_res;
			}
			return $arr_obj;
		}
		function dollarfy ($num,$dec) {
				$format="%.$dec" . "f";
				$number=sprintf($format,$num);
				$str=strtok($number,".");
				$dc=strtok(".");
				$str=$this->commify($str);
				$return="$str";
				if ($dec!=0){
					$return = "$$return";
				}
				return($return);
		}
		function commify ($str)  {
			$n = strlen($str);
			if ($n <= 3) {
					$return=$str;
			}
			else {
					$pre=substr($str,0,$n-3);
					$post=substr($str,$n-3,3);
					$pre=$this->commify($pre);
					$return="$pre,$post";
			}
			return($return);
		}
	}
?>

<?php 

class Environment { 

	private  function url() {
		return sprintf("%s://%s%s", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['SERVER_NAME'], $_SERVER['REQUEST_URI']);
	}

	private  function host() {
		return parse_url(self::url(), PHP_URL_HOST);
	}	

	public  function env() {
		$host = self::host();
		if ($host === "192.168.2.34") {
			$env = "vinfo";
		}
		return $env;
	}

	public  function iniConfig() {
		return $config_file_name = self::env().'.ini';
	}

	public  function isDebug() {
		$debug = false;
		if(array_key_exists('debug',$_GET)) {
			$debug = true;
		}
		return $debug;
	}

	public  function altorouterBaseUrl() {
		$env = self::env();
		if($env === 'vinfo') {
			$uri_root = implode(array_slice(explode('/', $_SERVER['REQUEST_URI']), 1, 1), '/') . "/";
		} else {
			$uri_root = '';
		}
		return $uri_root;
	}

	public  function baseUrl() {
		$url_parts = explode('/', self::url());
		$offset	   = 0;

		if(self::env() === 'vinfo') {
			$length = 4;
		} else {
		   $length = 3;
		}
		return implode(array_slice($url_parts, $offset, $length), '/');
	}
}

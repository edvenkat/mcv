<?php 
error_reporting(0);
ini_set("display_errors","0");

define("APP_ROOT"		, dirname(__DIR__) . '/');
define("APP_ASSETS"		, APP_ROOT . 'assets/');
define("CONTROLLER_ROOT", APP_ROOT . 'controllers/');
define("VIEW_ROOT"		, APP_ROOT . 'views/');
define("VENDOR_ROOT"	, APP_ROOT . 'vendor/');
define("CONFIG_ROOT"	, APP_ROOT . 'config/');
define("HELPER_ROOT"	, APP_ROOT . 'helpers/');
define("MODEL_ROOT"		, APP_ROOT . 'models/');

require_once ( HELPER_ROOT."Util.php" );
require_once ( CONFIG_ROOT.'Environment.php' );
require_once ( CONFIG_ROOT.'InIConfig.php' );
require_once ( VENDOR_ROOT.'altorouter/AltoRouter.php' );
require_once ( HELPER_ROOT.'Routes.php' );
require_once ( CONTROLLER_ROOT.'AppController.php' );
require_once ( MODEL_ROOT."data.sources/ActiveRecord.php" );


define("_HOME_", 'http://192.168.2.34/richardsonscharts-new/');
define("_ENV_", Environment::env());
define("_ALTO_BASE_PATH_", Environment::altorouterBaseUrl());
define("_BASE_URL_", Environment::altorouterBaseUrl());

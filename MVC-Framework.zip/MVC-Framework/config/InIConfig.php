<?php

class InIConfig	 {
	public static $ini_array;
	
	public static function initializeConfig($config_file_name) {
		self::$ini_array = parse_ini_file(CONFIG_ROOT.$config_file_name, true);
		
		if(Util::isEmpty(self::$ini_array)) {
			throw new Exception(__METHOD__.": CONFIGURATION ERROR - ".$config_file_name." empty.");
		} else {
			return self::$ini_array;
		}
	}

	public static function getSectionParams($section_name) {
		return self::$ini_array[$section_name];
	}

	public static function getSectionParam($section_name, $param_name) {
		return self::$ini_array[$section_name][$param_name];
	}
}
